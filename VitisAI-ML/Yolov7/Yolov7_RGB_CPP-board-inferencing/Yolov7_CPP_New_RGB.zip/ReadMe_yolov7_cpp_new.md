

# This is Yolov7 C++ inference project for RGB Video(webm or other raw video) or Camera.

Prerequisite:
1. KV260 Board , power adapter, SD card with Vitis AI 3.0 board image.
2. USB Camera - logitech camera of 720p or 1080p. We are using logitech C525 USB for this demo.

## For running this , follow these steps:

1. Download this Zip file in Host PC.
2. Copy it to KV260 Board (Vitis AI Image 3.0 version).
3. Extract the Zip file on the board.

4. Goto "yolov7_cpp_new" and run:

./yolov7_cpp_new
- it will show you inference run sequence like:  <application> <video_file> <xmodel>

5. Now you can run:
./yolov7_cpp_new /dev/video0 ./Yolov7_320_rgb.xmodel